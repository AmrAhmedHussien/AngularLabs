import { EventEmitter } from "@angular/core";
import { throttleTime } from "rxjs";
import { Product } from "../_models/product.model";

export class productService {
    itemAdded: EventEmitter<any> = new EventEmitter<any>();
    constructor() { }
    productArray: Product[] = [
        {
            id: 1, name: 'photo camera', price: 100, discount: 10, imageURL: 'https://picsum.photos/200/300', description: 'hahaha', counter: 0
        },
        {
            id: 2, name: 'photo ', price: 100, discount: 10, imageURL: 'https://picsum.photos/200/200', description: 'hahaha', counter: 0
        },
        {
            id: 3, name: ' camera', price: 100, imageURL: 'https://picsum.photos/200/100', description: 'hahaha', counter: 0
        },
        {
            id: 4, name: 'photo camera', price: 200, discount: 10, imageURL: 'https://picsum.photos/200/400', description: 'hahaha', counter: 0
        },
        {
            id: 5, name: 'photo camera', price: 300, discount: 10, imageURL: 'https://picsum.photos/200/500', description: 'hahaha', counter: 0
        },
        {
            id: 6, name: 'photo camera', price: 400, discount: 10, imageURL: 'https://picsum.photos/200/600', description: 'hahaha', counter: 0
        },
        {
            id: 7, name: 'photo camera', price: 500, discount: 10, imageURL: 'https://picsum.photos/200/700', description: 'hahaha', counter: 0
        },
        {
            id: 8, name: 'photo camera', price: 600, discount: 10, imageURL: 'https://picsum.photos/200/800', description: 'hahaha', counter: 0
        },
        {
            id: 9, name: 'photo camera', price: 100, discount: 10, imageURL: 'https://picsum.photos/200/900', description: 'hahaha', counter: 0
        }
    ];
    cartArray: Product[] = [];

    getAllProducts(): Product[] {
        return this.productArray.slice();
    }
    getproductByID(id: number): Product | undefined {
        return this.productArray.find(i => i.id === id);
    }
    addProduct(product: Product): void {
        this.productArray.push(product);

    }
    delProduct(id: number): Product[] {
        return this.productArray.filter(item => item.id != id)
    }
    addToCart(product: Product) {
        if (!this.cartArray.includes(product)) {
            this.cartArray.push(product);
        }
        


        const res = this.cartArray;
        return res;
    }
    updateProduct(id: number) {

    }
    removeFromCart(i:number){
        if (this.cartArray[i].counter! >1) {
            this.cartArray[i].counter!--;
          }
          else{
            this.cartArray.splice(i,1);
          }
    }
}