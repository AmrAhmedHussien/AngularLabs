import { StringMap } from "@angular/compiler/src/compiler_facade_interface";

export interface Product{
    id:number,
    name : string,
    price: number,
    discount?: number,
    imageURL:String,
    description:string,
    counter?:number
}